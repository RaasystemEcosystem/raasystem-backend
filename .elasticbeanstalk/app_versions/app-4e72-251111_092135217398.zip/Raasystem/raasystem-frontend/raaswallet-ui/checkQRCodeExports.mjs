import * as QRCodeLib from "qrcode.react";

console.log(QRCodeLib);

