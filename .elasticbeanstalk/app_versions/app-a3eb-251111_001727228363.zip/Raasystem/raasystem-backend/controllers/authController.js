exports.test = (req, res) => {
  res.json({ message: 'Auth route working' });
};
