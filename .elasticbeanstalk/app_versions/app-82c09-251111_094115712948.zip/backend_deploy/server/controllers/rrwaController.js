// server/controllers/rrwaController.js
exports.mintController = (req, res) => {
  res.status(200).json({ message: '✅ Mint successful!' });
};
